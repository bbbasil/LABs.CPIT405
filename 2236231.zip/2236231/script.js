const resultsBox = document.getElementById("results");
const searchBtn = document.getElementById("search-btn");
const searchInput = document.getElementById("search-input");

const defaultSuggestions = [
  "King Saud University",
  "King Abdulaziz University",
  "King Fahd University of Petroleum and Minerals",
  "Princess Nourah Bint Abdulrahman University",
  "Imam Abdulrahman Bin Faisal University",
  "Umm Al-Qura University"
];

function showSuggestions() {
  let html = "<h3>Popular Saudi Universities</h3>";
  defaultSuggestions.forEach(u => {
    html += `<p>• ${u}</p>`;
  });
  resultsBox.innerHTML = html;
}

function searchSaudiUniversities() {
  const name = searchInput.value.trim();
  fetch("http://universities.hipolabs.com/search?country=Saudi%20Arabia&name=" + name)
    .then(res => res.json())
    .then(data => displayResults(data));
}

function displayResults(list) {
  if (list.length === 0) {
    resultsBox.innerHTML = "<p>No universities found.</p>";
    return;
  }

  let html = "";
  list.forEach(u => {
    html += `
      <div class="university">
        <h3>${u.name}</h3>
        <p><strong>Country:</strong> ${u.country}</p>
        <p><a href="${u.web_pages[0]}" target="_blank">Visit Website</a></p>
      </div>
    `;
  });

  resultsBox.innerHTML = html;
}

searchBtn.addEventListener("click", searchSaudiUniversities);

showSuggestions();
